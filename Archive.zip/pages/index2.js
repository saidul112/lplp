import LayoutFront from "../components/layout/LayoutFront";

const Index2 = () => {
    
    return (
        <>
            <LayoutFront pageClass={"front"}>
                
            </LayoutFront>
        </>
    );
};

export default Index2;