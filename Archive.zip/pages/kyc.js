import LayoutFront from "../components/layout/LayoutFront";

const Kyc3 = () => {
	return (
		<>
			<LayoutFront pageClass={"front"}>
				
                
			</LayoutFront>
		</>
	);
};

export default Kyc3;
