import LayoutFront from "../components/layout/LayoutFront";

const IgoApply = () => {
    
    return (
        <>
            <LayoutFront pageClass={"front"}>
               
            </LayoutFront>
        </>
    );
};

export default IgoApply;