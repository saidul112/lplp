import LayoutFront from "../components/layout/LayoutFront";

const Calendar = () => {
    
    return (
        <>
            <LayoutFront pageClass={"front"}>
                
            </LayoutFront>
        </>
    );
};

export default Calendar;