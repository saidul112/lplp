import LayoutFront from "../components/layout/LayoutFront";

const Staking = () => {
    
    return (
        <>
            <LayoutFront pageClass={"front"}>
                
            </LayoutFront>
        </>
    );
};

export default Staking;