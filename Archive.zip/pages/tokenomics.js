import LayoutFront from "../components/layout/LayoutFront";

const Tokenomics = () => {
    
    return (
        <>
            <LayoutFront pageClass={"front"}>
                
            </LayoutFront>
        </>
    );
};

export default Tokenomics;